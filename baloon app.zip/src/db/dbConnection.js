const mongoose = require('mongoose')

const connectDB = async () => {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/baloon-app', {
            useNewUrlParser: true,
            autoIndex: true,
            keepAlive: true,
            useUnifiedTopology: true,
        })
        console.log('Database Connected successfully. ')
    } catch (error) {
        console.log(error.message)
        process.exit(1)
    }
}

module.exports = { connectDB }

const express = require('express');
const commonRoutes = require('./commonRoute'); // common routes
const userRoutes = require('./userRoute'); // normal user routes
const adminRoutes = require('./adminRoute'); // admin routes


const router = express.Router();

/** Common routes */
router.use('/', commonRoutes);


/** Normal user routes */
router.use('/users', userRoutes);


/** Admin routes */
router.use('/admin', adminRoutes);


module.exports = router;

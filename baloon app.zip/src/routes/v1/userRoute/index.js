const express = require('express');

const router = express.Router();
const userRoute = require('./user.route'); // user routes


router.use('/user', userRoute);

module.exports = router;

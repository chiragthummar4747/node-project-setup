const { Role } = require('../models');

/************************************************************
    Seeding roles - seeding records if not in database
************************************************************/
const rolesData = [
    {
        role: 'Admin',
        isActive: true,
        deletedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        role: 'User',
        isActive: true,
        deletedAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
    },
];

// Roles seeder
async function roleSeeder() {
    try {

        for (let roles of rolesData) {
            const alreadyExist = await Role.findOne({ role: roles.role });

            if (!alreadyExist) {
                return Role.create(roles);
            }
        }

        console.log('Role seeded successfully!');
    } catch (error) {
        console.log('Error from role seeder: ', error);
    }
}

module.exports = {
    roleSeeder,
};

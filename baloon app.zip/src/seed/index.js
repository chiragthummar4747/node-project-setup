const { connectDB } = require('../db/dbConnection')
const { roleSeeder } = require('./role.seeder')
const { adminSeeder } = require('./admin.seeder')

async function seeder() {
    await connectDB()

    try {
        console.log('Seeding database...')


        roleSeeder()   // role seeder
        adminSeeder() // admin seeder

    } catch (error) {
        console.log('Error  while database seeding', error)
    }
}

seeder()
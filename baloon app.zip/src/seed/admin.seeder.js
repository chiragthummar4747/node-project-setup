const { User, Role } = require('../models');

/************************************************************
    Seeding admins - seeding records if not in database
    Admin records seeding in users collection.
************************************************************/
const adminData = [
    {
        first_name: 'Baloon',
        last_name: 'Game',
        email: 'admin@baloongame.com',
        password: 'Admin@123',
        isActive: true,
        deletedAt: null
    },
];

async function findRole() {
    const roleType = await Role.findOne({ role: 'Admin' });
    return roleType?.id;
}

async function adminSeeder() {
    const roleId = await findRole();

    try {
        for (let admin of adminData) {
            const alreadyExist = await User.findOne({ email: admin.email.toLowerCase() });

            if (!alreadyExist) {
                await User.create({
                    first_name: admin.first_name,
                    last_name: admin.last_name,
                    email: admin.email.toLowerCase(),
                    role: roleId,
                    password: admin.password,
                    isActive: admin.isActive,
                    deletedAt: admin.deletedAt
                });
            }
        }

        console.log('Admin seeded successfully!');
    } catch (error) {
        console.log('Error from admin seeder: ', error);
    }
}

module.exports = { adminSeeder };
